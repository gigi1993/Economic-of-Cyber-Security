<?php

	// createCsv();

	// variables
	$outputPath = './output/';
	$apkPath = './apk/';
	$apikey = 'c66ff1413697b164b3b75ff26207d9e1d7f3d4409670ed1500adad69903e23db';
	$arrayMasterData = array();

	// include class
	require_once('virustotal.class.php');

	// get input file
	$array_csv = array_map('str_getcsv', file('./data/data.csv'));

	foreach ($array_csv as $data) {
		$scanData = array();
		// echo $data[9];

		// get filename
		$url = $data[9];
		// $path = parse_url($url, PHP_URL_PATH);
		// $pathFragments = explode('/', $path);
		// $fileName = end($pathFragments);
		$fileName = $data[7];
		$fileFullPath = $apkPath . $fileName . ".apk";

		// push details into array
		array_push($scanData, $data['2']); // category
		array_push($scanData, $data['1']); // app name
		array_push($scanData, $data['8']); // download times
		array_push($scanData, $data['9']); // URL
		array_push($scanData, $fileName); // filename
		// echo $end;
		// echo "<br>";

		$vt = new virustotal($apikey);
		$res = $vt->checkFile($fileFullPath); // $hash is optional. Pass the $scan_id if you have it, or the file hash
		switch($res) {
			case -99: // API limit exceeded
				// deal with it here – best by waiting a little before trying again :)
				$json_response = "case -99";
				break;
			case  -1: // an error occured
				// deal with it here
				$json_response = "case -1";
				break;
			case   0: // no results (yet) – but the file is already enqueued at VirusTotal
				$scan_id = $vt->getScanId();
				$json_response = $vt->getResponse();
				break;
			case   1: // results are available
				$json_response = $vt->getResponse();
				break;
				default : // you should not reach this point if you've placed the break before :)
		}
		// deal with the JSON response here

		$virusTotalResponses = json_decode($json_response, true);

		array_push($scanData, $virusTotalResponses['total']); // Total
		array_push($scanData, $virusTotalResponses['positives']); // Detection

		foreach ($virusTotalResponses['scans'] as $dataScan) {
			array_push($scanData, $dataScan['result']);
		}

		$formattedOutput = formatOutput($scanData);

		array_push($arrayMasterData, $formattedOutput);

	    // echo '<pre>'; var_dump(json_decode($json_response, true)); echo '</pre>'; exit();
	    sleep(25);
	}

	createCsv($arrayMasterData);
	
	echo "<pre>"; var_dump($arrayMasterData); echo "</pre>"; exit;

	// 
    function formatOutput($arrayInput) {
    	$stringReturn = "";
    	$i = 0;
    	$len = count($arrayInput);

    	foreach ($arrayInput as $formatOutputData) {
		    if ($i == $len - 1) {
		        $stringReturn = $stringReturn . $formatOutputData;
		    } else {
		    	$stringReturn = $stringReturn . $formatOutputData . ",";
		    }

    		$i++;
    	}

    	// $stringReturn = $arrayReturn[''] . ",";

    	return $stringReturn;
    }

    // 
    function createCsv($arrayInput = '') {

		if(empty($arrayInput)) {
			echo "input empty";
			break;
		}

		$file = fopen("./output/output.csv","w");

		foreach ($arrayInput as $line)
		{
			fputcsv($file, explode(',', $line));
		}

		fclose($file);

		// break;
    }

?> 