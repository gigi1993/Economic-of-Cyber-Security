<?php

	// variables
	$downloadPath = './apk/';

	// get input file
	$array_csv = array_map('str_getcsv', file('./data/data.csv'));

	foreach ($array_csv as $data) {

		//get url
		$url = $data[9];

		// get filename
		// $path = parse_url($url, PHP_URL_PATH);
		// $pathFragments = explode('/', $path);
		// $fname = end($pathFragments);
		$fname = $data[7] . ".apk";

		// download file
		copy($url, $downloadPath . $fname);
		// echo $downloadPath . $fname;

		// echo $url;
		echo $fname . " downloaded..";
		echo "<br>";
	}

	echo "Download finished!";

?>